// chart_frame.js
// Listens for chart data/config and renders Chart.js chart in the iframe

let chartInstance = null;

window.addEventListener('message', function(event) {
  if (!event.data || event.data.type !== 'ADZOOMA_EXT_RENDER_CHART') return;
  const { chartData, chartOptions } = event.data;
  // Patch y2 axis ticks callback for percent
  if (chartOptions && chartOptions.scales && chartOptions.scales.y2 && chartOptions.scales.y2.ticks) {
    chartOptions.scales.y2.ticks.callback = v => v + '%';
  }
  const canvas = document.getElementById('chart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  if (chartInstance) {
    chartInstance.destroy();
  }
  chartInstance = new window.Chart(ctx, {
    type: 'line',
    data: chartData,
    options: chartOptions
  });
}); 