(function() {
  window.addEventListener('message', function(event) {
    if (event.source !== window || !event.data || event.data.type !== 'ADZOOMA_EXT_RENDER_CHART') return;
    try {
      const { canvasId, chartData, chartOptions } = event.data;
      const canvas = document.getElementById(canvasId);
      if (!canvas) {
        console.warn('[AdzoomaExt] Injected chart: canvas not found:', canvasId);
        return;
      }
      if (!(window.Chart)) {
        console.warn('[AdzoomaExt] Injected chart: Chart.js not available on window.');
        return;
      }
      // Destroy previous chart instance if any
      if (canvas._adzoomaChartInstance && typeof canvas._adzoomaChartInstance.destroy === 'function') {
        canvas._adzoomaChartInstance.destroy();
      }
      const ctx = canvas.getContext('2d');
      const chartInstance = new window.Chart(ctx, {
        type: 'line',
        data: chartData,
        options: chartOptions
      });
      canvas._adzoomaChartInstance = chartInstance;
      console.log('[AdzoomaExt] Injected chart: Chart.js chart rendered', chartInstance);
    } catch (err) {
      console.error('[AdzoomaExt] Injected chart: Error rendering chart', err);
    }
  });
})(); 