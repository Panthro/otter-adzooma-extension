(function() {
  window.addEventListener('message', async (event) => {
    if (event.source !== window || !event.data || event.data.type !== 'ADZOOMA_EXT_FETCH') return;
    try {
      const { url, options, requestId } = event.data;
      const response = await fetch(url, options);
      const text = await response.text();
      window.postMessage({
        type: 'ADZOOMA_EXT_FETCH_RESULT',
        requestId,
        ok: response.ok,
        status: response.status,
        text,
        headers: Array.from(response.headers.entries())
      }, '*');
    } catch (err) {
      window.postMessage({
        type: 'ADZOOMA_EXT_FETCH_RESULT',
        requestId: event.data.requestId,
        error: err.message
      }, '*');
    }
  });
})(); 